package com.example.serving_web_content;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServingWebContentApplicationTests {

	@Test
	void contextLoads() {
	}

}
